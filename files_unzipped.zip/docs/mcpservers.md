# MCP Servers

Included Services:
- **Upstash Redis (serverless pub/sub, cache):** handles notifications and event broadcasting
- **Neon PostgreSQL:** stores persistent rabbit, task, and journal data
- **Railway PostgreSQL/MongoDB:** alternative robust managed DB

All are free-tier scalable, multi-cloud platform-ready.