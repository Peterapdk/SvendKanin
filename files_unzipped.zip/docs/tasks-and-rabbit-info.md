# Managing Tasks & Rabbit Info

## Rabbit Info
- Add/edit rabbit profiles: name, breed, age, medical history

## Tasks
- Track recurring and time-bound tasks (e.g., medication)
- View journal entries, associate with rabbit profile
- AI prompts/questions based on recent task/journal history