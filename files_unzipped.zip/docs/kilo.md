# Kilo Code Integration

Kilo code is set up in the backend for tracking key rabbit care events:
- Call `trackRabbitEvent(event)` in `kilo.js`
- Data can be visualized or exported for analytics

Kilo code CLI is installed in the devcontainer.